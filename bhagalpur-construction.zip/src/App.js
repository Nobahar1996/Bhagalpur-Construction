
export default function App() {
  return (
    <main style={{ minHeight: '100vh', backgroundColor: '#f3f4f6', padding: '1.5rem' }}>
      <div style={{ maxWidth: '768px', margin: '0 auto', textAlign: 'center' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#1f2937', marginBottom: '0.5rem' }}>
          Bhagalpur Construction
        </h1>
        <p style={{ fontSize: '1.25rem', color: '#4b5563', marginBottom: '1.5rem' }}>
          Building Dreams, Brick by Brick in Bhagalpur, Bihar
        </p>

        <section style={{ backgroundColor: 'white', borderRadius: '1rem', boxShadow: '0 0 10px rgba(0,0,0,0.1)', padding: '1.5rem', marginBottom: '1.5rem' }}>
          <h2 style={{ fontSize: '1.5rem', fontWeight: '600', color: '#1f2937', marginBottom: '1rem' }}>
            Our Services
          </h2>
          <ul style={{ textAlign: 'left', color: '#374151' }}>
            <li>🏠 Home Building</li>
            <li>🔧 Remodeling & Renovation</li>
            <li>🏢 Commercial Construction</li>
            <li>🏗️ Structural Repairs</li>
            <li>🛠️ Roofing and Waterproofing</li>
          </ul>
        </section>

        <section style={{ backgroundColor: 'white', borderRadius: '1rem', boxShadow: '0 0 10px rgba(0,0,0,0.1)', padding: '1.5rem' }}>
          <h2 style={{ fontSize: '1.5rem', fontWeight: '600', color: '#1f2937', marginBottom: '1rem' }}>
            Why Choose Us?
          </h2>
          <p style={{ color: '#374151' }}>
            With years of experience and a passionate team, Bhagalpur Construction delivers high-quality, reliable construction solutions tailored to your needs. From blueprint to final brick, we stand by your side.
          </p>
        </section>

        <footer style={{ marginTop: '2.5rem', color: '#6b7280', fontSize: '0.875rem' }}>
          Located in Bhagalpur, Bihar | Contact us at <a href="mailto:info@bhagalpurconstruction.com" style={{ color: '#3b82f6' }}>info@bhagalpurconstruction.com</a>
        </footer>
      </div>
    </main>
  );
}
